# Zuhud Studio

Editor video Android (Kotlin + Jetpack Compose + Media3).

Fitur: potong durasi, rasio (9:16, 1:1, 16:9, 4:5), crop bebas, 20 filter, 20 transisi masuk,
50 gaya teks, 50 stiker emoji, layer gambar, musik latar (dari tablet atau link .mp3), ekspor ke galeri.
Latar aplikasi bergaya grafiti "ZUHUD".

## Build tanpa PC
Push ke GitHub (branch main) -> tab Actions -> unduh artifact `app-debug-apk` -> install.
Hapus versi lama dulu sebelum install, karena tanda tangan debug berbeda tiap build.
