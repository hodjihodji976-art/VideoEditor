package com.example.videoeditor

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.Crop
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.TextureOverlay
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.MediaItem.ClippingConfiguration
import androidx.media3.effect.MatrixTransformation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.delay
import java.io.File
import kotlin.math.PI
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFFFF4DDB),
                    onPrimary = Color.White,
                    secondary = Color(0xFF4DF3FF),
                    secondaryContainer = Color(0xFF5A1A6B),
                    onSecondaryContainer = Color.White,
                    surface = Color(0xFF101018),
                    background = Color(0xFF101018)
                )
            ) {
                EditorScreen()
            }
        }
    }
}

// ------------------------------------------------------------------
// DATA
// ------------------------------------------------------------------

data class StickerLayer(
    val emoji: String,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val size: Float = 0.2f
)

data class EditParams(
    val cropL: Float,
    val cropR: Float,
    val cropT: Float,
    val cropB: Float,
    val aspect: Float?,
    val filterIndex: Int,
    val transitionIndex: Int,
    val text: String,
    val styleIndex: Int,
    val textSize: Float,
    val textX: Float,
    val textY: Float,
    val stickers: List<StickerLayer>,
    val bitmap: Bitmap?,
    val imageSize: Float,
    val imageX: Float,
    val imageY: Float,
    val videoW: Int,
    val videoH: Int
)

class EditorState {
    var videoUri by mutableStateOf<Uri?>(null)
    var videoW by mutableIntStateOf(0)
    var videoH by mutableIntStateOf(0)
    var durationMs by mutableLongStateOf(0L)
    var range by mutableStateOf(0f..1f)
    var status by mutableStateOf("Pilih video untuk mulai")
    var exporting by mutableStateOf(false)

    var ratioIndex by mutableIntStateOf(0)
    var cropL by mutableFloatStateOf(0f)
    var cropR by mutableFloatStateOf(0f)
    var cropT by mutableFloatStateOf(0f)
    var cropB by mutableFloatStateOf(0f)

    var filterIndex by mutableIntStateOf(0)
    var transitionIndex by mutableIntStateOf(0)

    var text by mutableStateOf("")
    var styleIndex by mutableIntStateOf(0)
    var textSize by mutableFloatStateOf(0.5f)
    var textX by mutableFloatStateOf(0.5f)
    var textY by mutableFloatStateOf(0.85f)

    var stickers by mutableStateOf<List<StickerLayer>>(emptyList())
    var selSticker by mutableIntStateOf(-1)

    var bitmap by mutableStateOf<Bitmap?>(null)
    var imageSize by mutableFloatStateOf(0.2f)
    var imageX by mutableFloatStateOf(0.85f)
    var imageY by mutableFloatStateOf(0.15f)

    var audioUri by mutableStateOf<Uri?>(null)
    var audioLabel by mutableStateOf("Belum ada musik")
    var muteOriginal by mutableStateOf(false)
    var urlText by mutableStateOf("")

    fun params() = EditParams(
        cropL, cropR, cropT, cropB,
        ratioOptions[ratioIndex].second,
        filterIndex, transitionIndex,
        text, styleIndex, textSize, textX, textY,
        stickers,
        bitmap, imageSize, imageX, imageY,
        videoW, videoH
    )
}

private val ratioOptions: List<Pair<String, Float?>> = listOf(
    "Asli" to null,
    "9:16" to 9f / 16f,
    "1:1" to 1f,
    "16:9" to 16f / 9f,
    "4:5" to 4f / 5f
)

// ------------------------------------------------------------------
// FILTER (20 + Normal)
// ------------------------------------------------------------------

private class FilterSpec(
    val name: String,
    val sat: Float = 1f,
    val contrast: Float = 1f,
    val bright: Float = 0f,
    val r: Float = 1f,
    val g: Float = 1f,
    val b: Float = 1f
)

private val filters: List<FilterSpec> = listOf(
    FilterSpec("Normal"),
    FilterSpec("Vivid", sat = 1.35f, contrast = 1.08f),
    FilterSpec("Cinematic", sat = 0.95f, contrast = 1.18f, bright = -0.02f, r = 1.06f, b = 0.94f),
    FilterSpec("Vintage", sat = 0.65f, contrast = 0.92f, bright = 0.05f, r = 1.08f, b = 0.86f),
    FilterSpec("Hitam Putih", sat = 0f, contrast = 1.1f),
    FilterSpec("Noir", sat = 0f, contrast = 1.45f, bright = -0.06f),
    FilterSpec("Sepia", sat = 0.35f, bright = 0.02f, r = 1.15f, b = 0.78f),
    FilterSpec("Hangat", r = 1.1f, g = 1.02f, b = 0.9f),
    FilterSpec("Dingin", r = 0.92f, b = 1.12f),
    FilterSpec("Pudar", sat = 0.8f, contrast = 0.8f, bright = 0.08f),
    FilterSpec("Pastel", sat = 0.7f, contrast = 0.9f, bright = 0.09f),
    FilterSpec("Golden Hour", sat = 1.15f, bright = 0.02f, r = 1.12f, g = 1.04f, b = 0.85f),
    FilterSpec("Moody", sat = 0.8f, contrast = 1.2f, bright = -0.05f, b = 1.05f),
    FilterSpec("Neon", sat = 1.7f, contrast = 1.12f),
    FilterSpec("Dreamy", sat = 1.15f, contrast = 0.9f, bright = 0.06f, r = 1.05f, b = 1.04f),
    FilterSpec("VHS Retro", sat = 1.2f, contrast = 0.95f, bright = 0.02f, r = 1.05f, b = 1.08f),
    FilterSpec("Matte", sat = 0.9f, contrast = 0.85f, bright = 0.05f),
    FilterSpec("Sunset", sat = 1.25f, contrast = 1.05f, r = 1.15f, g = 0.98f, b = 0.88f),
    FilterSpec("Es", sat = 0.9f, bright = 0.02f, r = 0.9f, g = 1.02f, b = 1.15f),
    FilterSpec("Drama", sat = 1.1f, contrast = 1.35f, bright = -0.03f),
    FilterSpec("Cerah", sat = 1.1f, contrast = 1.05f, bright = 0.06f)
)

private fun filterMatrix(f: FilterSpec): FloatArray {
    val lr = 0.2126f
    val lg = 0.7152f
    val lb = 0.0722f
    val s = f.sat
    val sat = arrayOf(
        floatArrayOf(lr * (1 - s) + s, lg * (1 - s), lb * (1 - s)),
        floatArrayOf(lr * (1 - s), lg * (1 - s) + s, lb * (1 - s)),
        floatArrayOf(lr * (1 - s), lg * (1 - s), lb * (1 - s) + s)
    )
    val gains = floatArrayOf(f.r, f.g, f.b)
    val out = FloatArray(16)
    for (row in 0..2) {
        val k = f.contrast * gains[row]
        for (col in 0..2) {
            out[col * 4 + row] = sat[row][col] * k
        }
        out[12 + row] = 0.5f * (1f - f.contrast) + f.bright
    }
    out[15] = 1f
    return out
}

// ------------------------------------------------------------------
// TRANSISI (20 + Tanpa) - animasi di awal video
// ------------------------------------------------------------------

private const val TRANSITION_US = 900_000f

private fun easeOut(p: Float): Float {
    val q = 1f - p
    return 1f - q * q * q
}

private fun easeOutBack(p: Float): Float {
    val c1 = 1.70158f
    val c3 = c1 + 1f
    val q = p - 1f
    return 1f + c3 * q * q * q + c1 * q * q
}

private fun easeOutBounce(p: Float): Float {
    var x = p
    val n1 = 7.5625f
    val d1 = 2.75f
    return if (x < 1f / d1) {
        n1 * x * x
    } else if (x < 2f / d1) {
        x -= 1.5f / d1
        n1 * x * x + 0.75f
    } else if (x < 2.5f / d1) {
        x -= 2.25f / d1
        n1 * x * x + 0.9375f
    } else {
        x -= 2.625f / d1
        n1 * x * x + 0.984375f
    }
}

private fun mat(
    tx: Float = 0f,
    ty: Float = 0f,
    sx: Float = 1f,
    sy: Float = 1f,
    rot: Float = 0f,
    skewX: Float = 0f,
    aspect: Float = 1f
): Matrix {
    val m = Matrix()
    m.postScale(sx.coerceAtLeast(0.001f), sy.coerceAtLeast(0.001f))
    if (skewX != 0f) m.postSkew(skewX, 0f)
    if (rot != 0f) {
        m.postScale(aspect, 1f)
        m.postRotate(rot)
        m.postScale(1f / aspect, 1f)
    }
    m.postTranslate(tx, ty)
    return m
}

private class Tr(val name: String, val fade: Boolean, val geom: ((Float, Float) -> Matrix)?)

private val transitions: List<Tr> = listOf(
    Tr("Tanpa", false, null),
    Tr("Fade In", true, null),
    Tr("Zoom In", false, { p, _ -> val s = 1.6f - 0.6f * easeOut(p); mat(sx = s, sy = s) }),
    Tr("Zoom Out", true, { p, _ -> val s = 0.4f + 0.6f * easeOut(p); mat(sx = s, sy = s) }),
    Tr("Geser Kanan", false, { p, _ -> mat(tx = 2f * (1f - easeOut(p))) }),
    Tr("Geser Kiri", false, { p, _ -> mat(tx = -2f * (1f - easeOut(p))) }),
    Tr("Geser Atas", false, { p, _ -> mat(ty = 2f * (1f - easeOut(p))) }),
    Tr("Geser Bawah", false, { p, _ -> mat(ty = -2f * (1f - easeOut(p))) }),
    Tr("Putar", false, { p, a ->
        val e = easeOut(p)
        val s = 0.3f + 0.7f * e
        mat(sx = s, sy = s, rot = 180f * (1f - e), aspect = a)
    }),
    Tr("Putar Zoom", true, { p, a ->
        val e = easeOut(p)
        mat(sx = e, sy = e, rot = -360f * (1f - e), aspect = a)
    }),
    Tr("Goyang", false, { p, _ -> mat(tx = sin(p * 50f) * 0.06f * (1f - p)) }),
    Tr("Denyut", false, { p, _ ->
        val s = 1f + 0.15f * sin(p * PI.toFloat() * 4f) * (1f - p)
        mat(sx = s, sy = s)
    }),
    Tr("Pintu Horizontal", false, { p, _ -> mat(sx = easeOut(p)) }),
    Tr("Pintu Vertikal", false, { p, _ -> mat(sy = easeOut(p)) }),
    Tr("Pop", false, { p, _ -> val s = easeOutBack(p); mat(sx = s, sy = s) }),
    Tr("Miring", false, { p, _ -> mat(skewX = 0.6f * (1f - easeOut(p))) }),
    Tr("Zoom Fade", true, { p, _ -> val s = 1.3f - 0.3f * easeOut(p); mat(sx = s, sy = s) }),
    Tr("Geser Fade", true, { p, _ -> mat(tx = 0.5f * (1f - easeOut(p))) }),
    Tr("Jatuh", false, { p, _ -> mat(ty = 2f * (1f - easeOutBounce(p))) }),
    Tr("Naik", false, { p, _ -> mat(ty = -2f * (1f - easeOutBack(p))) }),
    Tr("Glitch", false, { p, _ ->
        val k = if ((p * 18f).toInt() % 2 == 0) 1f else -1f
        mat(tx = k * 0.07f * (1f - p))
    })
)

@OptIn(UnstableApi::class)
private class TransitionEffect(
    private val tr: Tr,
    private val aspect: Float,
    private val offsetUs: Long
) : MatrixTransformation {
    override fun getMatrix(presentationTimeUs: Long): Matrix {
        val p = ((presentationTimeUs - offsetUs) / TRANSITION_US).coerceIn(0f, 1f)
        return tr.geom?.invoke(p, aspect) ?: Matrix()
    }
}

@OptIn(UnstableApi::class)
private class FadeEffect(private val offsetUs: Long) : RgbMatrix {
    override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray {
        val p = ((presentationTimeUs - offsetUs) / TRANSITION_US).coerceIn(0f, 1f)
        val g = easeOut(p)
        return floatArrayOf(
            g, 0f, 0f, 0f,
            0f, g, 0f, 0f,
            0f, 0f, g, 0f,
            0f, 0f, 0f, 1f
        )
    }
}

// ------------------------------------------------------------------
// STIKER (50 emoji populer)
// ------------------------------------------------------------------

private val stickerEmojis: List<String> = listOf(
    "🔥", "✨", "💖", "😍", "😂", "🥹", "😎", "🤩", "🥳", "💯",
    "👑", "💎", "🌈", "⭐", "🌙", "☀️", "⚡", "💥", "🎉", "🎶",
    "🎧", "🎬", "📸", "💫", "🦋", "🌸", "🌹", "🍀", "🍓", "🍉",
    "🍕", "🍔", "🧋", "☕", "🐱", "🐶", "🐼", "🦄", "🚀", "✈️",
    "🏆", "💪", "🙏", "💀", "👻", "🤡", "🥰", "😭", "👀", "💘"
)

private val emojiCache = HashMap<String, Bitmap>()

private fun emojiBitmap(emoji: String): Bitmap = emojiCache.getOrPut(emoji) {
    val size = 256
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(bmp)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.textSize = 200f
    p.textAlign = Paint.Align.CENTER
    val y = size / 2f - (p.descent() + p.ascent()) / 2f
    c.drawText(emoji, size / 2f, y, p)
    bmp
}

// ------------------------------------------------------------------
// GAYA TEKS (50)
// ------------------------------------------------------------------

private const val W = 0xFFFFFFFFL
private const val K = 0xFF000000L

private class TextStyleSpec(
    val name: String,
    val fill: Long,
    val stroke: Long?,
    val strokeW: Float,
    val shadow: Long?,
    val bg: Long?,
    val family: String,
    val italic: Boolean,
    val caps: Boolean,
    val spacing: Float,
    val bold: Boolean
)

private fun ts(
    name: String,
    fill: Long,
    stroke: Long? = null,
    sw: Float = 0f,
    shadow: Long? = null,
    bg: Long? = null,
    fam: String = "sans-serif-black",
    ital: Boolean = false,
    caps: Boolean = false,
    sp: Float = 0f,
    bold: Boolean = true
) = TextStyleSpec(name, fill, stroke, sw, shadow, bg, fam, ital, caps, sp, bold)

private val textStyles: List<TextStyleSpec> = listOf(
    ts("Putih Bersih", W, K, 10f),
    ts("Neon Pink", 0xFFFF4DDBL, W, 6f, 0xFFFF4DDBL),
    ts("Neon Biru", 0xFF4DF3FFL, W, 4f, 0xFF00B8FFL),
    ts("Neon Hijau", 0xFF7CFF4DL, W, 4f, 0xFF2BFF00L),
    ts("Kuning Pop", 0xFFFFE600L, K, 12f),
    ts("Merah Bold", 0xFFFF2D2DL, W, 10f),
    ts("Label Hitam", W, bg = K),
    ts("Label Kuning", K, bg = 0xFFFFE600L),
    ts("Label Pink", W, bg = 0xFFFF4DA6L),
    ts("Kaca Gelap", W, bg = 0x99000000L, fam = "sans-serif-medium"),
    ts("Emas", 0xFFFFD54AL, 0xFF7A4B00L, 8f, K),
    ts("Perak", 0xFFE8EEF2L, 0xFF5A6672L, 8f),
    ts("Retro 80an", 0xFFFF6EC7L, 0xFF3A0CA3L, 10f, 0xFF00E5FFL, ital = true),
    ts("Vaporwave", 0xFFB388FFL, 0xFF00E5FFL, 6f, ital = true),
    ts("Sunset", 0xFFFF8A3DL, 0xFF5A0F2EL, 8f),
    ts("Ocean", 0xFF38D9FFL, 0xFF03396CL, 8f),
    ts("Hutan", 0xFF8CFF8CL, 0xFF0B3D0BL, 8f),
    ts("Lavender", 0xFFD9B8FFL, 0xFF4B2A7BL, 6f),
    ts("Mint", 0xFFB8FFE6L, 0xFF0A5C4AL, 6f),
    ts("Peach", 0xFFFFC2A8L, 0xFF8A3B1EL, 6f),
    ts("Minimalis", W, fam = "sans-serif-light", caps = true, sp = 0.15f, bold = false),
    ts("Elegan Serif", W, shadow = K, fam = "serif", ital = true),
    ts("Majalah", W, bg = 0xFF111111L, fam = "serif", caps = true, sp = 0.1f),
    ts("Typewriter", 0xFFF5F5F5L, bg = 0xAA000000L, fam = "monospace"),
    ts("Terminal Hijau", 0xFF33FF66L, bg = 0xFF001A08L, fam = "monospace"),
    ts("Tulisan Tangan", W, shadow = K, fam = "cursive", bold = false),
    ts("Kasual", 0xFFFFF176L, K, 6f, fam = "casual"),
    ts("Komik", W, K, 14f, fam = "casual", caps = true),
    ts("Graffiti", 0xFFFF4DDBL, 0xFF2B0A3DL, 12f, 0xFF00E5FFL, ital = true, caps = true),
    ts("Spray Hijau", 0xFF9CFF00L, 0xFF1B2A00L, 10f, ital = true, caps = true),
    ts("Api", 0xFFFF9A00L, 0xFFB00000L, 10f, 0xFFFF3D00L, caps = true),
    ts("Es Kristal", 0xFFE0F7FFL, 0xFF2E86C1L, 8f, 0xFF00B8FFL),
    ts("Horor", 0xFFB00020L, K, 10f, K, fam = "serif", ital = true),
    ts("Peringatan", K, bg = 0xFFFFC400L, fam = "sans-serif-condensed", caps = true),
    ts("Sinema", W, shadow = K, fam = "sans-serif-light", caps = true, sp = 0.3f, bold = false),
    ts("Judul Film", 0xFFF2E6C9L, shadow = K, fam = "serif", caps = true, sp = 0.2f),
    ts("Subtitle", W, K, 8f, fam = "sans-serif-medium"),
    ts("Subtitle Kuning", 0xFFFFEB3BL, K, 8f, fam = "sans-serif-medium"),
    ts("Podcast", W, bg = 0xFF6A1B9AL, fam = "sans-serif"),
    ts("Stiker Putih", 0xFF222222L, bg = W),
    ts("Pink Cyan", W, 0xFFFE2C55L, 6f, 0xFF25F4EEL),
    ts("Glitch", W, 0xFF00E5FFL, 4f, 0xFFFF1744L),
    ts("Chrome", 0xFFDDE6EEL, 0xFF1C2A38L, 8f, K),
    ts("Bubble", W, 0xFFFF4DA6L, 14f),
    ts("Candy", 0xFFFF8FD8L, W, 8f, 0xFFB300A0L),
    ts("Zamrud Mewah", 0xFFF3E5ABL, bg = 0xFF0B3D2EL, fam = "serif"),
    ts("Royal", 0xFFFFD700L, bg = 0xFF2A0B5EL, fam = "serif", ital = true),
    ts("Elegan Hitam", 0xFF111111L, W, 6f, fam = "serif"),
    ts("Bayangan Ungu", W, shadow = 0xFF6A1B9AL),
    ts("Rose", 0xFFFF5C8AL, W, 8f)
)

private val textCache = HashMap<String, Bitmap>()

private fun textBitmap(raw: String, st: TextStyleSpec): Bitmap {
    val key = raw + "|" + st.name
    textCache[key]?.let { return it }
    if (textCache.size > 40) textCache.clear()

    val shown = if (st.caps) raw.uppercase() else raw
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    val style = if (st.bold && st.italic) Typeface.BOLD_ITALIC
    else if (st.bold) Typeface.BOLD
    else if (st.italic) Typeface.ITALIC
    else Typeface.NORMAL
    paint.typeface = Typeface.create(st.family, style)
    paint.textSize = 100f
    paint.letterSpacing = st.spacing

    val textW = paint.measureText(shown)
    val fm = paint.fontMetrics
    val pad = 36f
    val bw = (textW + pad * 2).toInt().coerceIn(8, 4000)
    val bh = (fm.descent - fm.ascent + pad * 2).toInt().coerceAtLeast(8)
    val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(bmp)

    val bgColor = st.bg
    if (bgColor != null) {
        val bgp = Paint(Paint.ANTI_ALIAS_FLAG)
        bgp.color = bgColor.toInt()
        c.drawRoundRect(RectF(0f, 0f, bw.toFloat(), bh.toFloat()), 40f, 40f, bgp)
    }

    val x = pad
    val base = pad - fm.ascent

    val shadowColor = st.shadow
    if (shadowColor != null) {
        paint.style = Paint.Style.FILL
        paint.color = st.fill.toInt()
        paint.setShadowLayer(20f, 6f, 8f, shadowColor.toInt())
        c.drawText(shown, x, base, paint)
        paint.clearShadowLayer()
    }
    val strokeColor = st.stroke
    if (strokeColor != null && st.strokeW > 0f) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = st.strokeW
        paint.strokeJoin = Paint.Join.ROUND
        paint.color = strokeColor.toInt()
        c.drawText(shown, x, base, paint)
    }
    paint.style = Paint.Style.FILL
    paint.color = st.fill.toInt()
    c.drawText(shown, x, base, paint)

    textCache[key] = bmp
    return bmp
}

// ------------------------------------------------------------------
// PIPELINE EFEK
// ------------------------------------------------------------------

private fun formatMs(ms: Long): String {
    val totalSec = ms / 1000
    return "%02d:%02d".format(totalSec / 60, totalSec % 60)
}

private fun pct(v: Float): String = "${(v * 100).toInt()}%"

private fun displayName(context: Context, uri: Uri): String {
    val name: String? = try {
        context.contentResolver.query(
            uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
        )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (e: Exception) {
        null
    }
    return name ?: "audio"
}

private fun saveToGallery(context: Context, file: File): Boolean {
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ZuhudStudio")
    }
    val uri = context.contentResolver.insert(
        MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values
    ) ?: return false
    context.contentResolver.openOutputStream(uri)?.use { out ->
        file.inputStream().use { it.copyTo(out) }
    }
    file.delete()
    return true
}

private fun estimateFinalSize(p: EditParams): Pair<Float, Float> {
    val w = if (p.videoW > 0) p.videoW.toFloat() else 1080f
    val h = if (p.videoH > 0) p.videoH.toFloat() else 1920f
    val cw = (w * (1f - p.cropL - p.cropR)).coerceAtLeast(2f)
    val ch = (h * (1f - p.cropT - p.cropB)).coerceAtLeast(2f)
    val a = p.aspect ?: return Pair(cw, ch)
    return if (cw / ch > a) Pair(ch * a, ch) else Pair(cw, cw / a)
}

@OptIn(UnstableApi::class)
private fun overlaySettings(x: Float, y: Float, scale: Float): OverlaySettings =
    OverlaySettings.Builder()
        .setBackgroundFrameAnchor(-1f + 2f * x, 1f - 2f * y)
        .setScale(scale, scale)
        .build()

@OptIn(UnstableApi::class)
private fun buildEffects(p: EditParams, offsetUs: Long): List<Effect> {
    val effects = mutableListOf<Effect>()

    if (p.cropL > 0f || p.cropR > 0f || p.cropT > 0f || p.cropB > 0f) {
        effects.add(
            Crop(
                -1f + 2f * p.cropL,
                1f - 2f * p.cropR,
                -1f + 2f * p.cropB,
                1f - 2f * p.cropT
            )
        )
    }

    p.aspect?.let {
        effects.add(
            Presentation.createForAspectRatio(it, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
        )
    }

    if (p.filterIndex > 0) {
        val m = filterMatrix(filters[p.filterIndex])
        effects.add(object : RgbMatrix {
            override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray = m
        })
    }

    val size = estimateFinalSize(p)
    val finalW = size.first
    val finalH = size.second
    val overlays = mutableListOf<TextureOverlay>()

    if (p.text.isNotBlank()) {
        val bmp = textBitmap(p.text.trim(), textStyles[p.styleIndex])
        val scale = (finalW * p.textSize) / bmp.width
        overlays.add(
            BitmapOverlay.createStaticBitmapOverlay(bmp, overlaySettings(p.textX, p.textY, scale))
        )
    }

    for (s in p.stickers) {
        val bmp = emojiBitmap(s.emoji)
        val scale = (finalW * s.size) / bmp.width
        overlays.add(
            BitmapOverlay.createStaticBitmapOverlay(bmp, overlaySettings(s.x, s.y, scale))
        )
    }

    p.bitmap?.let { bmp ->
        val scale = (finalW * p.imageSize) / bmp.width
        overlays.add(
            BitmapOverlay.createStaticBitmapOverlay(
                bmp, overlaySettings(p.imageX, p.imageY, scale)
            )
        )
    }

    if (overlays.isNotEmpty()) {
        effects.add(OverlayEffect(ImmutableList.copyOf(overlays)))
    }

    if (p.transitionIndex > 0) {
        val tr = transitions[p.transitionIndex]
        if (tr.geom != null) {
            effects.add(TransitionEffect(tr, finalW / finalH, offsetUs))
        }
        if (tr.fade) {
            effects.add(FadeEffect(offsetUs))
        }
    }
    return effects
}

// ------------------------------------------------------------------
// LATAR GRAFITI "ZUHUD"
// ------------------------------------------------------------------

private val neon = intArrayOf(
    0xFFFF4DDB.toInt(), 0xFF4DF3FF.toInt(), 0xFF9CFF00.toInt(),
    0xFFFFE600.toInt(), 0xFFB388FF.toInt(), 0xFFFF8A3D.toInt()
)

@Composable
private fun GraffitiBackground() {
    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(Color(0xFF14141B))

        // tembok bata
        val rnd = java.util.Random(11)
        val bh = h / 30f
        val bw = w / 5f
        var y = 0f
        var row = 0
        while (y < h) {
            var x = if (row % 2 == 0) 0f else -bw / 2f
            while (x < w) {
                val shade = (26 + rnd.nextInt(16)) / 255f
                drawRect(
                    color = Color(shade, shade, shade + 0.03f),
                    topLeft = Offset(x + 2f, y + 2f),
                    size = Size(bw - 4f, bh - 4f)
                )
                x += bw
            }
            y += bh
            row++
        }

        val head = 150.dp.toPx()

        drawIntoCanvas { canvas ->
            val nc = canvas.nativeCanvas
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)

            // cipratan cat semprot
            repeat(26) {
                val cx = rnd.nextFloat() * w
                val cy = rnd.nextFloat() * h
                val r = w * (0.06f + 0.12f * rnd.nextFloat())
                val col = (neon[rnd.nextInt(neon.size)] and 0x00FFFFFF) or 0x44000000
                paint.shader = RadialGradient(cx, cy, r, col, 0x00000000, Shader.TileMode.CLAMP)
                nc.drawCircle(cx, cy, r, paint)
            }
            paint.shader = null

            // tulisan besar ZUHUD
            paint.typeface = Typeface.create("sans-serif-black", Typeface.BOLD_ITALIC)
            paint.textAlign = Paint.Align.CENTER
            val ts = minOf(w * 0.24f, head * 1.05f)
            paint.textSize = ts
            val cx = w / 2f
            val base = head * 0.95f

            nc.save()
            nc.rotate(-8f, cx, base)

            paint.style = Paint.Style.FILL_AND_STROKE
            paint.strokeWidth = ts * 0.22f
            paint.strokeJoin = Paint.Join.ROUND
            paint.color = 0xFF000000.toInt()
            nc.drawText("ZUHUD", cx + ts * 0.06f, base + ts * 0.07f, paint)

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = ts * 0.14f
            paint.color = 0xFFFFFFFF.toInt()
            nc.drawText("ZUHUD", cx, base, paint)

            paint.style = Paint.Style.FILL
            paint.shader = LinearGradient(
                cx - ts * 1.8f, 0f, cx + ts * 1.8f, 0f,
                intArrayOf(0xFFFF4DDB.toInt(), 0xFFFF8A3D.toInt(), 0xFFFFE600.toInt()),
                null, Shader.TileMode.CLAMP
            )
            nc.drawText("ZUHUD", cx, base, paint)
            paint.shader = null

            // tetesan cat
            val xs = floatArrayOf(-1.3f, -0.55f, 0.1f, 0.8f, 1.35f)
            xs.forEachIndexed { i, k ->
                val dx = cx + k * ts
                val y0 = base + ts * 0.1f
                val len = ts * (0.25f + 0.2f * (i % 3))
                paint.color = neon[i % neon.size]
                paint.style = Paint.Style.STROKE
                paint.strokeCap = Paint.Cap.ROUND
                paint.strokeWidth = ts * 0.05f
                nc.drawLine(dx, y0, dx, y0 + len, paint)
                paint.style = Paint.Style.FILL
                nc.drawCircle(dx, y0 + len, ts * 0.045f, paint)
            }
            nc.restore()

            // tag kecil di bawah
            paint.style = Paint.Style.FILL
            paint.typeface = Typeface.create("casual", Typeface.BOLD_ITALIC)
            paint.textSize = w * 0.09f
            paint.color = 0xFF4DF3FF.toInt()
            paint.setShadowLayer(24f, 0f, 0f, 0xFF4DF3FF.toInt())
            nc.save()
            nc.rotate(8f, w * 0.78f, h * 0.97f)
            nc.drawText("zuhud", w * 0.78f, h * 0.97f, paint)
            nc.restore()

            // tag samar di tengah
            paint.color = 0x55FF4DDB
            paint.setShadowLayer(0f, 0f, 0f, 0)
            paint.textSize = w * 0.08f
            nc.save()
            nc.rotate(-20f, w * 0.2f, h * 0.6f)
            nc.drawText("ZUHUD", w * 0.2f, h * 0.6f, paint)
            nc.restore()
            paint.clearShadowLayer()
        }
    }
}

// ------------------------------------------------------------------
// UI
// ------------------------------------------------------------------

@Composable
private fun SectionTitle(title: String) {
    Text(title, style = MaterialTheme.typography.titleMedium, color = Color(0xFF4DF3FF))
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    onChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float> = 0f..1f
) {
    Text(label)
    Slider(value = value, onValueChange = onChange, valueRange = range)
}

private val tabTitles = listOf("Potong", "Filter", "Transisi", "Teks", "Stiker", "Gambar", "Musik")

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun EditorScreen() {
    val context = LocalContext.current
    val st = remember { EditorState() }
    var tab by remember { mutableIntStateOf(0) }

    val exoPlayer = remember { ExoPlayer.Builder(context).build() }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    st.durationMs = exoPlayer.duration.coerceAtLeast(0L)
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(context, uri)
                var w = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                    ?.toIntOrNull() ?: 0
                var h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                    ?.toIntOrNull() ?: 0
                val rot = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                    ?.toIntOrNull() ?: 0
                if (rot == 90 || rot == 270) {
                    val t = w
                    w = h
                    h = t
                }
                st.videoW = w
                st.videoH = h
            } catch (e: Exception) {
                st.videoW = 0
                st.videoH = 0
            } finally {
                mmr.release()
            }
            st.videoUri = uri
            st.range = 0f..1f
            st.durationMs = 0L
            st.ratioIndex = 0
            st.cropL = 0f
            st.cropR = 0f
            st.cropT = 0f
            st.cropB = 0f
            exoPlayer.setMediaItem(MediaItem.fromUri(uri))
            exoPlayer.prepare()
            st.status = "Video dimuat."
        }
    }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val bmp = context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it)
            }
            st.bitmap = bmp?.let { b ->
                if (b.width > 1080) {
                    Bitmap.createScaledBitmap(
                        b, 1080, (b.height * 1080f / b.width).toInt().coerceAtLeast(1), true
                    )
                } else b
            }
        }
    }

    val audioPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            st.audioUri = uri
            st.audioLabel = "Dari tablet: " + displayName(context, uri)
        }
    }

    val params = st.params()
    val startMs = (st.range.start * st.durationMs).toLong()
    val endMs = (st.range.endInclusive * st.durationMs).toLong()

    // Pratinjau langsung (ditunda sebentar agar tidak berat saat slider digeser)
    LaunchedEffect(params, startMs) {
        if (st.videoUri == null) return@LaunchedEffect
        delay(400)
        try {
            exoPlayer.setVideoEffects(buildEffects(params, startMs * 1000L))
        } catch (e: Exception) {
            st.status = "Pratinjau efek gagal: ${e.message}"
        }
    }

    fun updateSticker(f: (StickerLayer) -> StickerLayer) {
        st.stickers = st.stickers.mapIndexed { i, s -> if (i == st.selSticker) f(s) else s }
    }

    Box(Modifier.fillMaxSize()) {
        GraffitiBackground()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // header: graffiti ZUHUD tampil di belakang area ini
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(150.dp)
            ) {
                Text(
                    "STUDIO",
                    color = Color(0xFF9CFF00),
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.align(Alignment.BottomEnd)
                )
            }

            Button(onClick = {
                videoPicker.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                )
            }) { Text("Pilih video") }

            if (st.videoUri != null) {
                AndroidView(
                    factory = { ctx -> PlayerView(ctx).apply { player = exoPlayer } },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                )

                Surface(
                    color = Color(0xB3101018),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    Column {
                        ScrollableTabRow(
                            selectedTabIndex = tab,
                            edgePadding = 8.dp,
                            containerColor = Color.Transparent
                        ) {
                            tabTitles.forEachIndexed { i, title ->
                                Tab(
                                    selected = tab == i,
                                    onClick = { tab = i },
                                    text = { Text(title) }
                                )
                            }
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            when (tab) {
                                0 -> {
                                    SectionTitle("Potong durasi")
                                    Text(
                                        "${formatMs(startMs)} – ${formatMs(endMs)} dari ${formatMs(st.durationMs)}"
                                    )
                                    RangeSlider(
                                        value = st.range,
                                        onValueChange = {
                                            st.range = it
                                            exoPlayer.seekTo((it.start * st.durationMs).toLong())
                                        },
                                        enabled = st.durationMs > 0
                                    )
                                    SectionTitle("Rasio (crop dari tengah)")
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        ratioOptions.forEachIndexed { i, option ->
                                            FilterChip(
                                                selected = st.ratioIndex == i,
                                                onClick = { st.ratioIndex = i },
                                                label = { Text(option.first) }
                                            )
                                        }
                                    }
                                    SectionTitle("Crop bebas")
                                    LabeledSlider("Kiri ${pct(st.cropL)}", st.cropL, { st.cropL = it }, 0f..0.4f)
                                    LabeledSlider("Kanan ${pct(st.cropR)}", st.cropR, { st.cropR = it }, 0f..0.4f)
                                    LabeledSlider("Atas ${pct(st.cropT)}", st.cropT, { st.cropT = it }, 0f..0.4f)
                                    LabeledSlider("Bawah ${pct(st.cropB)}", st.cropB, { st.cropB = it }, 0f..0.4f)
                                }

                                1 -> {
                                    SectionTitle("Filter (${filters.size - 1})")
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        filters.forEachIndexed { i, f ->
                                            FilterChip(
                                                selected = st.filterIndex == i,
                                                onClick = { st.filterIndex = i },
                                                label = { Text(f.name) }
                                            )
                                        }
                                    }
                                }

                                2 -> {
                                    SectionTitle("Efek transisi (${transitions.size - 1})")
                                    Text("Animasi masuk di 0,9 detik pertama video.")
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        transitions.forEachIndexed { i, t ->
                                            FilterChip(
                                                selected = st.transitionIndex == i,
                                                onClick = {
                                                    st.transitionIndex = i
                                                    exoPlayer.seekTo((st.range.start * st.durationMs).toLong())
                                                    exoPlayer.play()
                                                },
                                                label = { Text(t.name) }
                                            )
                                        }
                                    }
                                }

                                3 -> {
                                    SectionTitle("Teks")
                                    OutlinedTextField(
                                        value = st.text,
                                        onValueChange = { st.text = it.take(30) },
                                        label = { Text("Tulis teks (kosong = tanpa teks)") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    SectionTitle("Gaya teks (${textStyles.size})")
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        textStyles.forEachIndexed { i, s ->
                                            FilterChip(
                                                selected = st.styleIndex == i,
                                                onClick = { st.styleIndex = i },
                                                label = { Text(s.name) }
                                            )
                                        }
                                    }
                                    if (st.text.isNotBlank()) {
                                        LabeledSlider("Ukuran ${pct(st.textSize)}", st.textSize, { st.textSize = it }, 0.1f..1f)
                                        LabeledSlider("Posisi kiri–kanan", st.textX, { st.textX = it })
                                        LabeledSlider("Posisi atas–bawah", st.textY, { st.textY = it })
                                    }
                                }

                                4 -> {
                                    SectionTitle("Stiker (${stickerEmojis.size}) – ketuk untuk menambah")
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        stickerEmojis.forEach { e ->
                                            Text(
                                                e,
                                                fontSize = 30.sp,
                                                modifier = Modifier
                                                    .clickable {
                                                        if (st.stickers.size < 12) {
                                                            val n = st.stickers.size
                                                            st.stickers = st.stickers + StickerLayer(
                                                                emoji = e,
                                                                x = 0.3f + 0.1f * (n % 5),
                                                                y = 0.4f + 0.08f * (n % 5)
                                                            )
                                                            st.selSticker = st.stickers.lastIndex
                                                        }
                                                    }
                                                    .padding(6.dp)
                                            )
                                        }
                                    }
                                    if (st.stickers.isNotEmpty()) {
                                        SectionTitle("Stiker terpasang – ketuk untuk edit")
                                        FlowRow(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            st.stickers.forEachIndexed { i, s ->
                                                FilterChip(
                                                    selected = st.selSticker == i,
                                                    onClick = { st.selSticker = i },
                                                    label = { Text(s.emoji) }
                                                )
                                            }
                                        }
                                        val sel = st.stickers.getOrNull(st.selSticker)
                                        if (sel != null) {
                                            LabeledSlider("Ukuran ${pct(sel.size)}", sel.size,
                                                { v -> updateSticker { it.copy(size = v) } }, 0.05f..0.6f)
                                            LabeledSlider("Posisi kiri–kanan", sel.x,
                                                { v -> updateSticker { it.copy(x = v) } })
                                            LabeledSlider("Posisi atas–bawah", sel.y,
                                                { v -> updateSticker { it.copy(y = v) } })
                                            OutlinedButton(onClick = {
                                                st.stickers = st.stickers.filterIndexed { i, _ -> i != st.selSticker }
                                                st.selSticker = -1
                                            }) { Text("Hapus stiker ini") }
                                        }
                                    }
                                }

                                5 -> {
                                    SectionTitle("Layer gambar")
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = {
                                            imagePicker.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        }) { Text("Pilih gambar") }
                                        if (st.bitmap != null) {
                                            OutlinedButton(onClick = { st.bitmap = null }) { Text("Hapus") }
                                        }
                                    }
                                    if (st.bitmap != null) {
                                        LabeledSlider("Ukuran ${pct(st.imageSize)}", st.imageSize, { st.imageSize = it }, 0.05f..1f)
                                        LabeledSlider("Posisi kiri–kanan", st.imageX, { st.imageX = it })
                                        LabeledSlider("Posisi atas–bawah", st.imageY, { st.imageY = it })
                                    }
                                }

                                else -> {
                                    SectionTitle("Musik latar")
                                    Text(st.audioLabel)
                                    Button(onClick = {
                                        audioPicker.launch(arrayOf("audio/*"))
                                    }) { Text("Pilih dari tablet") }

                                    OutlinedTextField(
                                        value = st.urlText,
                                        onValueChange = { st.urlText = it },
                                        label = { Text("Link audio online (https://...mp3)") },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Button(onClick = {
                                        val u = st.urlText.trim()
                                        if (u.startsWith("https://")) {
                                            st.audioUri = Uri.parse(u)
                                            st.audioLabel = "Online: $u"
                                        } else {
                                            st.status = "Link harus diawali https://"
                                        }
                                    }) { Text("Pakai link ini") }

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Switch(
                                            checked = st.muteOriginal,
                                            onCheckedChange = { st.muteOriginal = it }
                                        )
                                        Text("Matikan suara asli video")
                                    }
                                    if (st.audioUri != null) {
                                        OutlinedButton(onClick = {
                                            st.audioUri = null
                                            st.audioLabel = "Belum ada musik"
                                        }) { Text("Hapus musik") }
                                    }
                                    Text(
                                        "Perpustakaan musik Facebook tidak punya akses publik, " +
                                            "jadi pakai file dari tablet atau link .mp3 langsung. " +
                                            "Musik terdengar di hasil ekspor, bukan di pratinjau.",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                }

                Button(
                    enabled = !st.exporting && st.durationMs > 0 && endMs - startMs >= 500,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        val uri = st.videoUri ?: return@Button
                        st.exporting = true
                        st.status = "Mengekspor... (jangan tutup aplikasi)"
                        val outFile = File(context.cacheDir, "zuhud_${System.currentTimeMillis()}.mp4")
                        val mediaItem = MediaItem.Builder()
                            .setUri(uri)
                            .setClippingConfiguration(
                                ClippingConfiguration.Builder()
                                    .setStartPositionMs(startMs)
                                    .setEndPositionMs(endMs)
                                    .build()
                            )
                            .build()
                        val videoItem = EditedMediaItem.Builder(mediaItem)
                            .setEffects(Effects(emptyList(), buildEffects(params, 0L)))
                            .setRemoveAudio(st.muteOriginal)
                            .build()

                        val transformer = Transformer.Builder(context)
                            .addListener(object : Transformer.Listener {
                                override fun onCompleted(
                                    composition: Composition,
                                    exportResult: ExportResult
                                ) {
                                    val ok = saveToGallery(context, outFile)
                                    st.exporting = false
                                    st.status = if (ok) "Selesai! Tersimpan di Movies/ZuhudStudio"
                                    else "Ekspor selesai, tapi gagal menyimpan ke galeri"
                                }

                                override fun onError(
                                    composition: Composition,
                                    exportResult: ExportResult,
                                    exportException: ExportException
                                ) {
                                    st.exporting = false
                                    st.status = "Gagal: ${exportException.message}"
                                }
                            })
                            .build()

                        val music = st.audioUri
                        if (music != null) {
                            val audioItem = EditedMediaItem.Builder(
                                MediaItem.Builder()
                                    .setUri(music)
                                    .setClippingConfiguration(
                                        ClippingConfiguration.Builder()
                                            .setEndPositionMs(endMs - startMs)
                                            .build()
                                    )
                                    .build()
                            ).build()
                            val composition = Composition.Builder(
                                ImmutableList.of(
                                    EditedMediaItemSequence(ImmutableList.of(videoItem)),
                                    EditedMediaItemSequence(ImmutableList.of(audioItem))
                                )
                            ).build()
                            transformer.start(composition, outFile.absolutePath)
                        } else {
                            transformer.start(videoItem, outFile.absolutePath)
                        }
                    }
                ) { Text(if (st.exporting) "Mengekspor..." else "Ekspor video") }
            }

            Text(st.status, color = Color.White)
        }
    }
}
