# Video Editor (starter)

Aplikasi Android editor video sederhana: pilih video, pratinjau, potong (trim), lalu ekspor ke galeri.
Dibangun dengan Kotlin, Jetpack Compose, dan Media3 (ExoPlayer + Transformer).

## Build tanpa PC (lewat GitHub Actions)
1. Push proyek ini ke repo GitHub (branch `main`).
2. Buka tab **Actions** → workflow **Build APK** berjalan otomatis (atau tekan **Run workflow**).
3. Setelah hijau, buka run tersebut → bagian **Artifacts** → unduh `app-debug-apk`.
4. Ekstrak zip, lalu install `app-debug.apk` di tablet (izinkan "install dari sumber tidak dikenal").

## Push dari tablet dengan Termux
```
pkg install git unzip
unzip VideoEditor.zip && cd VideoEditor
git init -b main
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/USERNAME/NAMA-REPO.git
git push -u origin main
```
Saat diminta password, pakai Personal Access Token GitHub (Settings → Developer settings → Tokens).

## Ide pengembangan berikutnya
- Gabung beberapa klip (Composition di Media3 Transformer)
- Teks/stiker (OverlayEffect), filter, kecepatan, musik
- Timeline multi-track, auto caption, template
